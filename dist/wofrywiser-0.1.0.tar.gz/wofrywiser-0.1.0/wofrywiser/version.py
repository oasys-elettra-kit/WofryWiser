
# THIS FILE IS GENERATED FROM wofrywise SETUP.PY
short_version = '0.1.0'
version = '0.1.0'
full_version = '0.1.0'
git_revision = '26616ce5b92895f3886f2da440ed0d9036516c77'
release = True

if not release:
    version = full_version
    short_version += ".dev"
