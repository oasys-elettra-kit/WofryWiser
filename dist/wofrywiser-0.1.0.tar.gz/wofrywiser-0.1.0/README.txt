WOFRY (Wave Optics FRamework in pYthon) for Wiser library

Kernel classes for WOFRY - Wiser in python.

It is an intermediate layer between LibWiser and Wofry. It exists in order to ensure interoperability between the rest of OASYS codes and LibWiser - numerical integration using Huygens integral.

syned package requires Python 3.3 or newer.


Work in progress

* initial layer for scripting


Installing

wofrywiser will be pip installable (https://pip.pypa.io/) by:

    pip install wofrywiser

to install it.

